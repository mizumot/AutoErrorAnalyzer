#!/bin/bash

echo "==================================="
echo "Python Environment Setup"
echo "==================================="

# アプリケーションのディレクトリに移動
cd "$(dirname "$0")" || exit 1

# Python3のインストール確認と実行
if ! command -v python3 &> /dev/null; then
    echo "Python is not installed."
    echo "Installing Python using Homebrew..."
    
    # Homebrewのインストール確認
    if ! command -v brew &> /dev/null; then
        echo "Installing Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        
        # Homebrewのパスを追加
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
    
    # Pythonのインストール
    brew install python
    echo "Python installation completed."
fi

# 仮想環境のセットアップ
if [ ! -d "venv" ]; then
    echo "Creating new virtual environment..."
    python3 -m venv venv
    
    if [ $? -eq 0 ]; then
        echo "Activating virtual environment..."
        source venv/bin/activate
        
        echo "Updating pip, setuptools, and wheel..."
        python3 -m pip install --upgrade pip
        pip install --upgrade setuptools wheel
        
        echo "Installing required packages..."
        if [ -f requirements.txt ]; then
            pip install -r requirements.txt
            if [ $? -ne 0 ]; then
                echo "Failed to install requirements."
                exit 1
            fi
        fi
        
        echo "Downloading spacy language model..."
        python3 -m spacy download en_core_web_md
        
        deactivate
    else
        echo "Failed to create virtual environment."
        exit 1
    fi
else
    echo "Found existing virtual environment."
    source venv/bin/activate
    
    echo "Updating pip..."
    python3 -m pip install --upgrade pip
    
    echo "Checking required packages..."
    if [ -f requirements.txt ]; then
        NEEDS_INSTALL=0
        while IFS= read -r line || [[ -n "$line" ]]; do
            PKG=$(echo "$line" | cut -d'=' -f1)
            PKG=$(echo "$PKG" | tr -d ' ')
            if ! pip show "$PKG" &> /dev/null; then
                NEEDS_INSTALL=1
                break
            fi
        done < requirements.txt

        if [ $NEEDS_INSTALL -eq 1 ]; then
            echo "Installing missing requirements..."
            pip install -r requirements.txt
            if [ $? -ne 0 ]; then
                echo "Failed to install requirements."
                exit 1
            fi
        else
            echo "All requirements are already installed."
        fi
    fi
    
    # spaCyモデルのチェックとインストール
    if ! python3 -c "import spacy; spacy.load('en_core_web_md')" &> /dev/null; then
        if pip show spacy &> /dev/null; then
            echo "Installing spaCy language model..."
            python3 -m spacy download en_core_web_md
        fi
    else
        echo "spaCy model is already installed."
    fi
fi

# アプリケーションの起動
echo "Starting the application..."
python3 app.py

# 終了処理
if [ $? -eq 0 ]; then
    echo "Application closed successfully."
else
    echo "Application exited with an error."
fi

# 仮想環境の無効化
deactivate

echo "==================================="
echo "Press any key to exit..."
read -n 1 -s